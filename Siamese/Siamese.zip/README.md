# Pytorch implementation of Siamese Network

## Description
Siamese network for face classification

## Train
```
python  SiameseNetworkTrain.py
```
## Test
```
python  SiameseNetworkTest.py
```
