python ../../bin/eval.py \
--tracker_path ./results \
--dataset VOT2018 \
--num 4 \
--tracker_prefix 'ch*'     