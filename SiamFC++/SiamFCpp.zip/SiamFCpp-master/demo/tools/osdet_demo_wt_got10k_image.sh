python3 demo/main/osdet/osdet_demo_wt_got10k_image.py --sequence-index=0  --template-frame=0 --search-frame=5
