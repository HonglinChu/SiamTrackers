python3 demo/main/osdet/osdet_demo_wt_static_image.py --shift-x=0.45 --shift-y=0.55
