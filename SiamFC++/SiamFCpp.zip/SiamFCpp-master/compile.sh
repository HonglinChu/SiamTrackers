# complie evaluation toolkit
pushd siamfcpp/evaluation/vot_benchmark
bash make.sh
popd